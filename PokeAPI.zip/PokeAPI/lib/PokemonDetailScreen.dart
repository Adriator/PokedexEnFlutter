import 'package:flutter/material.dart';
import 'pokemon.dart';

class PokemonDetailScreen extends StatelessWidget {
  final Pokemon pokemon;

  const PokemonDetailScreen({super.key, required this.pokemon});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(pokemon.name.toUpperCase()),
        backgroundColor: Colors.red,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(pokemon.imageUrl, height: 200, fit: BoxFit.cover),
            const SizedBox(height: 16),
            Text(
              'Name: ${pokemon.name.toUpperCase()}',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text('Height: ${pokemon.height} m'),
            Text('Weight: ${pokemon.weight} kg'),
            const SizedBox(height: 8),
            Text(
              'Types: ${pokemon.types.join(', ')}',
              style: const TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
