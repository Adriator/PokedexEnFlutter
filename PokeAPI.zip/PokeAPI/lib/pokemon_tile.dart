import 'package:flutter/material.dart';
import 'pokemon.dart';

class PokemonTile extends StatelessWidget {
  final Pokemon pokemon;

  const PokemonTile({super.key, required this.pokemon});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Image.network(pokemon.imageUrl),
      title: Text(pokemon.name),
    );
  }
}