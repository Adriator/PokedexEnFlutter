class Pokemon {
  final String name;
  final String imageUrl;
  final double weight;
  final double height;
  final List<String> types;

  Pokemon({
    required this.name,
    required this.imageUrl,
    required this.weight,
    required this.height,
    required this.types,
  });

  factory Pokemon.fromJson(Map<String, dynamic> json) {
    return Pokemon(
      name: json['name'],
      imageUrl: json['sprites']?['other']?['official-artwork']?['front_default'] ?? '',
      weight: json['weight'] / 10.0,  // Convertir peso a kg (si es en hectogramos)
      height: json['height'] / 10.0,  // Convertir altura a metros
      types: (json['types'] as List)
          .map((type) => type['type']['name'] as String)
          .toList(),
    );
  }
}
