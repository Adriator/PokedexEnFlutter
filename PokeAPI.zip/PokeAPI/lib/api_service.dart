import 'dart:convert';
import 'package:http/http.dart' as http;
import 'pokemon.dart';

class ApiService {
  static const String baseUrl = 'https://pokeapi.co/api/v2/pokemon';

  /// 🔹 Obtiene TODOS los Pokémon sin paginación
  Future<List<Pokemon>> fetchAllPokemons() async {
    final response = await http.get(Uri.parse('$baseUrl?limit=1025')); // Obtener 1000 Pokémon

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final List results = data['results'];

      List<Pokemon> pokemonList = [];

      for (var item in results) {
        final pokemonResponse = await http.get(Uri.parse(item['url']));
        if (pokemonResponse.statusCode == 200) {
          final pokemonData = json.decode(pokemonResponse.body);
          pokemonList.add(Pokemon.fromJson(pokemonData));
        }
      }

      return pokemonList;
    } else {
      throw Exception('Error al cargar los Pokémon');
    }
  }

  /// 🔍 Busca un Pokémon por nombre
  Future<Pokemon?> fetchPokemonByName(String name) async {
    final response = await http.get(Uri.parse('$baseUrl/$name'));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return Pokemon.fromJson(data);
    }
    return null;
  }
}
