import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'api_service.dart';
import 'pokemon.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ApiService _apiService = ApiService();
  List<Pokemon> _pokemons = [];
  List<Pokemon> _filteredPokemons = [];
  bool _isLoading = true;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadPokemons();
    _searchController.addListener(_filterPokemons);
  }

  Future<void> _loadPokemons() async {
    try {
      List<Pokemon> allPokemons = await _apiService.fetchAllPokemons();
      setState(() {
        _pokemons = allPokemons;
        _filteredPokemons = _pokemons;
        _isLoading = false;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${e.toString()}')),
      );
      setState(() => _isLoading = false);
    }
  }


  void _filterPokemons() async {
    String query = _searchController.text.trim().toLowerCase();

    if (query.isEmpty) {
      setState(() {
        _filteredPokemons = _pokemons;
      });
      return;
    }

    List<Pokemon> filteredList = _pokemons
        .where((pokemon) => pokemon.name.toLowerCase().contains(query))
        .toList();

    if (filteredList.isEmpty) {
      Pokemon? fetchedPokemon = await _apiService.fetchPokemonByName(query);
      if (fetchedPokemon != null) {
        setState(() {
          _filteredPokemons = [fetchedPokemon];
        });
      } else {
        /* ScaffoldMessenger.of(context).showSnackBar(
          //SnackBar(content: Text('No se encontró el Pokémon "$query"')),
        );*/
      }
    } else {
      setState(() {
        _filteredPokemons = filteredList;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.yellow[100], // Color de fondo estilo Pokémon
      appBar: AppBar(
        title: Text(
          'Pokédex',
          style: GoogleFonts.pressStart2p(fontSize: 18, color: Colors.white),
        ),
        backgroundColor: Colors.red, // Rojo Pokémon
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(56.0),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              style: GoogleFonts.pressStart2p(fontSize: 12, color: Colors.black),
              decoration: InputDecoration(
                hintText: 'Buscar Pokémon...',
                hintStyle: GoogleFonts.pressStart2p(fontSize: 10, color: Colors.black54),
                prefixIcon: const Icon(Icons.search, color: Colors.black),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10.0)),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
          ),
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
        onRefresh: _loadPokemons,
        child: GridView.builder(
          padding: const EdgeInsets.all(8.0),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 0.9,
          ),
          itemCount: _filteredPokemons.length,
          itemBuilder: (context, index) {
            return _buildPokemonCard(_filteredPokemons[index]);
          },
        ),
      ),
    );
  }

  Widget _buildPokemonCard(Pokemon pokemon) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      elevation: 5,
      color: Colors.white,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.network(pokemon.imageUrl, height: 100, fit: BoxFit.cover),
          const SizedBox(height: 8),
          Text(
            pokemon.name.toUpperCase(),
            style: GoogleFonts.pressStart2p(fontSize: 12, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}
