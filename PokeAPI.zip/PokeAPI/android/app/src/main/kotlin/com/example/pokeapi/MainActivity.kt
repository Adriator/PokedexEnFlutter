package com.example.pokeapi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
